password for 2 files is:myfansarethebest!

You Dont need to Open It on VM!!!

           =======================================
           =       B A S T E K                   =
           =                                     =
           =            J R                      =
           =                                     =
           =======================================